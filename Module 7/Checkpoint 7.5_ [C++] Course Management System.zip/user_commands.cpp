// Handling user commands

#include <iostream>
#include <string>
using namespace std;


int main() {
	string input;
	cin >> input;
	while (input != "exit") {
		if (input == "add") {
			// handle add commnad
		}
		if (input == "show") {
			// handle show commnad
		}
		cin >> input;
	}
	return 0;
}